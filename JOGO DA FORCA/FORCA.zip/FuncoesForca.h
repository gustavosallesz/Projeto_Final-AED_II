#ifndef FUNCOES_H
#define FUNCOES_H

#include <graphics.h>
#include <windows.h>

// Fun��o para corrigir a acentua��o
void ortografia();

// Sele��o de modo de jogo
void selecModo();

// Escolhe uma palavra aleat�ria e retorna a dica associada
char* escolhePalavra();

// Fun��o principal do jogo
void jogo();


#endif
